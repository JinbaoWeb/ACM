#include <stdio.h>
#include <string.h>
#include <algorithm>
#define MAXN 100005
using namespace std;
struct note
{
	int u,v;
	note () {}
	note (int u,int v) : u(u),v(v) {}
}p[MAXN*2];
int dfn[MAXN],low[MAXN],iscut[MAXN],head[MAXN],ne[MAXN*2],vis[MAXN],stk[MAXN],S[MAXN],L[MAXN],belong[MAXN];
int e,n,m,cu,cv,index,top,cnt;
void init()
{
	e=0;
	cnt=0;
	memset(head,-1,sizeof(head));
	memset(vis,0,sizeof(vis));
	memset(belong,0,sizeof(belong));
}
void addnote(int u,int v)
{
	p[e] = note(u,v);
	ne[e]=head[u];
	head[u]=e++;
}
void tarjan(int x,int fa)
{
	printf("%d %d\n",index,top );
	vis[x]=1;
	dfn[x]=low[x]=++index;
	stk[top++]=x;
	for (int i=head[x];i+1;i=ne[i])
	{
		if (fa==p[i].v) continue;
		if (!vis[p[i].v])
		{
			tarjan(p[i].v,x);
			low[x]=min(low[x],low[p[i].v]);
		}
		else 
			low[x]=min(low[x],dfn[p[i].v]);
	}
	// if (low[x]>=dfn[x])
	// {
	// 	cnt++;
	// 	L[cnt]=0;
	// 	do{
	// 		top--;
	// 		belong[stk[top]]=cnt;
	// 		L[cnt]=max(L[cnt],stk[top]);
	// 	}while(stk[top]!=x);
	// }
}
void dfs(int x,int fa)
{
	vis[x]=1;S[x]=L[x];
	for (int i=head[x];i+1;i=ne[i])
		if (!vis[p[i].v])
			dfs(p[i].v,x);
	S[fa]=max(S[fa],S[x]);
	//printf("dfs %d %d\n",x,S[x] );
}
int main(int argc, char const *argv[])
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		init();
		scanf("%d%d",&n,&m);
		for (int i=0;i<m;i++)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			addnote(u,v);
			addnote(v,u);
		}
		index=top=0;
		tarjan(1,0);
		//for (int i=1;i<=n;i++) printf("%d ",belong[i] );printf("\n");
		// memset(head,-1,sizeof(head));
		// for (int i=0;i<e;i++)
		// {
		// 	p[i].v=belong[p[i].v];
		// 	p[i].u=belong[p[i].u];
		// 	ne[i]=head[p[i].u];
		// 	head[p[i].u]=i;
		// }
		// memset(vis,0,sizeof(vis));
		// dfs(belong[n],0);
		//for (int i=1;i<=cnt;i++) printf("%d ",L[i]);printf("\n");
		//for (int i=1;i<=cnt;i++) printf("%d ",S[i] );printf("\n");
		// for (int i=0;i<e;i=i+2)
		// {
		// 	//printf("%d %d %d ",i,p[i].u,p[i].v );
		// 	if (belong[p[i].u]==belong[p[i].v])
		// 		printf("0 0\n");
		// 	else
		// 	{
		// 		int pp=min(S[p[i].u],S[p[i].v]);
		// 		printf("%d %d\n",pp,pp+1);
		// 	}
		// }
		// for (int i=1;i<=n;i++)
		// 	printf("%d %d %d\n",i,dfn[i],low[i] );
		//printf("%d %d\n",cu,cv );
	}
	return 0;
}